#include <stdio.h>

#define MAX 10

void dfs(int graph[MAX][MAX], int n, int start, int visited[MAX]) {
    printf("%d ", start);
    visited[start] = 1;

    for (int i = 0; i < n; i++) {
        if (graph[start][i] == 1 && !visited[i])
            dfs(graph, n, i, visited);
    }
}

int main() {
    int n, i, j, start;
    int graph[MAX][MAX];
    int visited[MAX] = {0};

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix of the graph:\n");
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            scanf("%d", &graph[i][j]);

    printf("Enter starting vertex: ");
    scanf("%d", &start);

    printf("DFS Traversal: ");
    dfs(graph, n, start, visited);
    printf("\n");

    return 0;
}
