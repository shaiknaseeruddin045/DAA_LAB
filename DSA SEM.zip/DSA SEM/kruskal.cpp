#include <stdio.h>

#define V 5   // number of vertices
#define E 7   // number of edges

// Structure to represent an edge
struct Edge {
    int src, dest, weight;
};

// Function to find the parent of a vertex (used in Union-Find)
int findParent(int parent[], int i) {
    if (parent[i] == i)
        return i;
    return findParent(parent, parent[i]);
}

// Function to perform union of two sets
void unionSet(int parent[], int x, int y) {
    int xroot = findParent(parent, x);
    int yroot = findParent(parent, y);
    parent[yroot] = xroot;
}

// Function to sort edges in ascending order of weights
void sortEdges(struct Edge edges[]) {
    int i, j;
    for (i = 0; i < E - 1; i++) {
        for (j = i + 1; j < E; j++) {
            if (edges[i].weight > edges[j].weight) {
                struct Edge temp = edges[i];
                edges[i] = edges[j];
                edges[j] = temp;
            }
        }
    }
}

// Kruskal�s algorithm
void kruskal(struct Edge edges[]) {
    int parent[V];
    struct Edge result[V - 1];
    int e = 0, i = 0;
    int totalCost = 0;

    // Step 1: Sort edges by weight
    sortEdges(edges);

    // Step 2: Initialize each vertex to be its own parent
    for (int v = 0; v < V; v++)
        parent[v] = v;

    // Step 3: Pick the smallest edge and check for cycle
    while (e < V - 1 && i < E) {
        struct Edge next_edge = edges[i++];

        int x = findParent(parent, next_edge.src);
        int y = findParent(parent, next_edge.dest);

        if (x != y) { // no cycle
            result[e++] = next_edge;
            unionSet(parent, x, y);
            totalCost += next_edge.weight;
        }
    }

    // Step 4: Print the resulting MST
    printf("Edge : Weight\n");
    for (i = 0; i < e; i++)
        printf("%d - %d : %d\n", result[i].src, result[i].dest, result[i].weight);

    printf("Total cost of Minimum Spanning Tree = %d\n", totalCost);
}

int main() {
    struct Edge edges[E] = {
        {0, 1, 2},
        {0, 3, 6},
        {1, 3, 8},
        {1, 2, 3},
        {1, 4, 5},
        {2, 4, 7},
        {3, 4, 9}
    };

    kruskal(edges);
    return 0;
}
