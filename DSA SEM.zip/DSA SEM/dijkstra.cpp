#include <stdio.h>
#include <limits.h>

#define V 5   // number of vertices
#define E 8   // number of edges
#define INF 9999

struct Edge {
    int src, dest, weight;
};

void dijkstra(struct Edge edges[], int src) {
    int distance[V], visited[V];
    int i, j, u, minDist;

    // Step 1: Initialize distances and visited array
    for (i = 0; i < V; i++) {
        distance[i] = INF;
        visited[i] = 0;
    }
    distance[src] = 0;

    // Step 2: Repeat V-1 times
    for (i = 0; i < V - 1; i++) {
        // Pick vertex with minimum distance not yet visited
        minDist = INF;
        for (j = 0; j < V; j++)
            if (!visited[j] && distance[j] < minDist) {
                minDist = distance[j];
                u = j;
            }

        visited[u] = 1;

        // Step 3: Relax all edges outgoing from u
        for (j = 0; j < E; j++) {
            if (edges[j].src == u) {
                int v = edges[j].dest;
                int w = edges[j].weight;

                if (!visited[v] && distance[u] + w < distance[v])
                    distance[v] = distance[u] + w;
            }
        }
    }

    // Step 4: Print results
    printf("Vertex\tDistance from Source %d\n", src);
    for (i = 0; i < V; i++)
        printf("%d\t\t%d\n", i, distance[i]);
}

int main() {
    struct Edge edges[E] = {
        {0, 1, 10},
        {0, 3, 30},
        {0, 4, 100},
        {1, 2, 50},
        {2, 4, 10},
        {3, 2, 20},
        {3, 4, 60},
        {1, 3, 40}
    };

    int source = 0;
    dijkstra(edges, source);

    return 0;
}
