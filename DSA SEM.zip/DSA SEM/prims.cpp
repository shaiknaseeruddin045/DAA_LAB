#include <stdio.h>
#define INF 9999
#define V 5  // number of vertices

void prims(int graph[V][V]) {
    int selected[V]; // track selected vertices
    int i, j, ne = 0; // number of edges in MST
    int x, y; // vertices
    int totalCost = 0;

    // Step 1: mark all vertices as not selected
    for (i = 0; i < V; i++)
        selected[i] = 0;

    // Step 2: start from vertex 0
    selected[0] = 1;

    printf("Edge : Weight\n");

    // Step 3: repeat until V-1 edges are selected
    while (ne < V - 1) {
        int min = INF;
        x = 0;
        y = 0;

        // Find the smallest edge connecting a selected vertex to an unselected vertex
        for (i = 0; i < V; i++) {
            if (selected[i]) {
                for (j = 0; j < V; j++) {
                    if (!selected[j] && graph[i][j]) {
                        if (min > graph[i][j]) {
                            min = graph[i][j];
                            x = i;
                            y = j;
                        }
                    }
                }
            }
        }

        printf("%d - %d : %d\n", x, y, graph[x][y]);
        totalCost += graph[x][y];
        selected[y] = 1;
        ne++;
    }

    printf("Total cost of Minimum Spanning Tree = %d\n", totalCost);
}

int main() {
    int graph[V][V] = {
        {0, 2, 0, 6, 0},
        {2, 0, 3, 8, 5},
        {0, 3, 0, 0, 7},
        {6, 8, 0, 0, 9},
        {0, 5, 7, 9, 0}
    };

    prims(graph);
    return 0;
}
